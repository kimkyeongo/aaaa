package com.kedu.namecard.lib;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.kedu.namecard.vo.namecardVO;

public class NameCardUpdate {
	StringBuilder sb = null;
	public StringBuilder update(String commack){
		sb = new StringBuilder();
		sb.append("UPDATE namecard SET 	");
		if(commack.contains("1")){
			sb.append("name = ? 			");
		}
		if(commack.contains("2")){
			sb.append("mobile = ? 			");
		}
		if(commack.contains("3")){
			sb.append("email = ? 			");
		}
		if(commack.contains("4")){
			sb.append("company = ? 			");
		}
		sb.append("WHERE NO = ? ");
		
		return sb;
	}
	
	public PreparedStatement setPs(namecardVO nVo,PreparedStatement pstmt,String commack) throws SQLException {
		if(commack.contains("1")){
			pstmt.setString(1, nVo.getName());
		}else if(commack.contains("2")){
			System.out.println("잘봐 찍힐꺼야");
			System.out.println(nVo.getMobile());
			pstmt.setString(1, nVo.getMobile());
		}else if(commack.contains("3")){
			pstmt.setString(1, nVo.getEmail());
		}else if(commack.contains("4")){
			pstmt.setString(1, nVo.getCompany());
		}
		pstmt.setInt(2, nVo.getNo());
		return pstmt;
	}
}
