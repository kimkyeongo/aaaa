package com.kedu.namecard.app;

import com.kedu.namecard.lib.NameCardInterface;

public class StartNameCard {

	public static void main(String[] args) {
		// 시작하는 인스턴스 만 구현
		new NameCardInterface().start();
		
	}
}
